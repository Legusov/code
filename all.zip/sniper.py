import os
import requests
import pandas as pd
import numpy as np
import time
import matplotlib.pyplot as plt
from datetime import datetime, timedelta, timezone

# ==================== КОНФИГУРАЦИЯ (СНАЙПЕР v7.0 - ТАНК) ====================
CONFIG = {
    "INTERVAL": "60",
    "DAYS_BACK": 730,  # <--- 2 ГОДА
    "FORCE_RELOAD": False,
    "LEVERAGE": 10,
    "INITIAL_CAPITAL": 10_000.0,
    "RISK_PER_TRADE_PCT": 0.025,  # <--- РИСК 2.5% (Как рекомендовал аудитор)
    "COMMISSION": 0.00055,
    "MAX_CONCURRENT_POSITIONS": 3,
    "MAX_MARGIN_USAGE": 0.8,
    # Детектор импульса
    "LOOKBACK_CANDLES": 2,
    "PRICE_CHANGE_THRESHOLD": 0.01,
    "VOLUME_MULTIPLIER": 2.0,
    "EMA_PERIOD": 200,
    "MIN_EMA_DIST": 0.035,
    "MAX_EMA_DIST": 0.08,
    "RSI_PERIOD": 14,
    # Сделка
    "SL_PCT": 0.03,
    "TP_PCT": None,
    "MAX_HOLD_CANDLES": 72,
    "EARLY_EXIT_CANDLES": 12,
    # Пирамидинг
    "PYRAMID_ENABLED": True,
    "PYRAMID_LEVELS": 3,
    "PYRAMID_STEP_PCT": 0.015,
    "PYRAMID_SIZE_FRACTION": 1.0,
    # Трейлинг
    "TRAILING_ENABLED": True,
    "TRAIL_ACTIVATE_PCT": 0.015,
    "TRAIL_DISTANCE_PCT": 0.01,
    "TRAIL_TIGHTEN_PCT": 0.005,
}

BASE_URL = "https://api.bybit.com"
CACHE_DIR = "cache"


# ==================== КЭШ ====================
def _cache_path(symbol, interval):
    os.makedirs(CACHE_DIR, exist_ok=True)
    return os.path.join(CACHE_DIR, f"{symbol}_{interval}.csv")


def _load_cache(symbol, interval):
    path = _cache_path(symbol, interval)
    if not os.path.exists(path): return None
    try:
        df = pd.read_csv(path, dtype={"timestamp": "int64"})
        if df.empty: return None
        if df["timestamp"].iloc[0] < 1577836800000:
            os.remove(path);
            return None
        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
        return df.sort_values("timestamp").reset_index(drop=True)
    except:
        os.remove(path);
        return None


def _save_cache(symbol, interval, df):
    path = _cache_path(symbol, interval)
    df_to_save = df.copy()
    df_to_save["timestamp"] = df_to_save["timestamp"].apply(lambda x: int(x.timestamp() * 1000))
    cols = ["timestamp", "open", "high", "low", "close", "volume", "turnover"]
    df_to_save = df_to_save[[c for c in cols if c in df_to_save.columns]]
    df_to_save.to_csv(path, index=False)


# ==================== ЗАГРУЗКА С API ====================
def _download(symbol, interval, start_ms, end_ms):
    out = []
    cur_end = end_ms
    page = 0
    while cur_end > start_ms:
        page += 1
        params = {"category": "linear", "symbol": symbol, "interval": interval,
                  "end": cur_end, "limit": 1000}
        try:
            resp = requests.get(f"{BASE_URL}/v5/market/kline", params=params, timeout=15).json()
        except:
            break
        if resp.get("retCode") != 0: break
        kl = resp["result"]["list"]
        if not kl: break
        out.extend(kl)
        oldest = int(kl[-1][0])
        if oldest >= cur_end: break
        if oldest <= start_ms: break
        cur_end = oldest - 1
        time.sleep(0.05)  # <--- Ускорили загрузку
    if not out: return pd.DataFrame()
    df = pd.DataFrame(out, columns=["timestamp", "open", "high", "low", "close", "volume", "turnover"]).drop_duplicates(
        "timestamp")
    df["timestamp"] = pd.to_datetime(df["timestamp"].astype(np.int64), unit="ms", utc=True)
    for c in ["open", "high", "low", "close", "volume"]: df[c] = df[c].astype(float)
    return df.sort_values("timestamp").reset_index(drop=True)


def fetch_klines(symbol, interval, start_ms, end_ms, force_reload=False):
    candle_ms = int(interval) * 60 * 1000
    cached = None if force_reload else _load_cache(symbol, interval)
    if cached is not None and len(cached) > 0:
        c_min_ms = int(cached["timestamp"].iloc[0].timestamp() * 1000)
        c_max_ms = int(cached["timestamp"].iloc[-1].timestamp() * 1000)
        if c_min_ms <= start_ms + candle_ms and c_max_ms >= end_ms - candle_ms:
            t0 = pd.Timestamp(start_ms, unit="ms", tz="UTC")
            t1 = pd.Timestamp(end_ms, unit="ms", tz="UTC")
            return cached[(cached["timestamp"] >= t0) & (cached["timestamp"] <= t1)].reset_index(drop=True)
        if c_min_ms <= start_ms + candle_ms and c_max_ms < end_ms - candle_ms:
            new_part = _download(symbol, interval, c_max_ms + 1, end_ms)
            if len(new_part) > 0:
                combined = pd.concat([cached, new_part], ignore_index=True).drop_duplicates("timestamp").sort_values(
                    "timestamp").reset_index(drop=True)
                _save_cache(symbol, interval, combined)
                t0 = pd.Timestamp(start_ms, unit="ms", tz="UTC")
                t1 = pd.Timestamp(end_ms, unit="ms", tz="UTC")
                return combined[(combined["timestamp"] >= t0) & (combined["timestamp"] <= t1)].reset_index(drop=True)
            return cached
    df = _download(symbol, interval, start_ms, end_ms)
    if len(df) > 0: _save_cache(symbol, interval, df)
    return df


# ==================== ФИЛЬТР МОНЕТ (2+ ГОДА ПО launchTime) ====================
def get_valid_symbols():
    print("Запрос списка всех фьючерсов USDT...", flush=True)
    url = f"{BASE_URL}/v5/market/instruments-info?category=linear"
    resp = requests.get(url, timeout=15).json()

    all_syms = resp['result']['list']
    two_years_ago_ms = int((datetime.now(timezone.utc) - timedelta(days=730)).timestamp() * 1000)

    valid_syms = []
    for s in all_syms:
        if s['quoteCoin'] != 'USDT' or s['status'] != 'Trading':
            continue
        launch_time = int(s.get('launchTime', 0))
        if launch_time > 0 and launch_time < two_years_ago_ms:
            valid_syms.append(s['symbol'])

    print(f"✅ Отобрано монет с историей 2+ года: {len(valid_syms)}", flush=True)
    return valid_syms


# ==================== ИНДИКАТОРЫ ====================
def calculate_rsi(df, period=14):
    delta = df["close"].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    return 100 - (100 / (1 + rs))


def add_indicators(df):
    df = df.copy()
    df["vol_ma"] = df["volume"].rolling(20).mean()
    df["vol_ratio"] = df["volume"] / df["vol_ma"]
    df["rsi"] = calculate_rsi(df)
    df["ema_200"] = df["close"].ewm(span=CONFIG["EMA_PERIOD"], adjust=False).mean()
    return df


# ==================== ХЕДЖИРОВАНИЕ (BTC FILTER) ====================
def get_btc_trend(btc_df):
    btc_df = add_indicators(btc_df)
    trend_map = {}
    for _, r in btc_df.iterrows():
        trend_map[r["timestamp"]] = "up" if r["close"] > r["ema_200"] else "down"
    return trend_map


def generate_signals(df, btc_trend_map, cfg):
    sig = pd.Series(0, index=df.index)
    for i in range(max(cfg["LOOKBACK_CANDLES"], cfg["EMA_PERIOD"]), len(df)):
        r = df.iloc[i]
        prev_close = df.iloc[i - cfg["LOOKBACK_CANDLES"]]["close"]

        if pd.isna(r["vol_ma"]) or r["vol_ma"] == 0 or pd.isna(r["ema_200"]) or pd.isna(r["rsi"]):
            continue

        btc_status = btc_trend_map.get(r["timestamp"], "down")
        vol_spike = r["volume"] > r["vol_ma"] * cfg["VOLUME_MULTIPLIER"]
        ema_dist = (r["close"] / r["ema_200"]) - 1

        panic_drop = (r["close"] < prev_close * (1 - cfg["PRICE_CHANGE_THRESHOLD"]))
        is_green = r["close"] > r["open"]

        euphoria_pop = (r["close"] > prev_close * (1 + cfg["PRICE_CHANGE_THRESHOLD"]))
        is_red = r["close"] < r["open"]

        if vol_spike and btc_status == "up":
            if panic_drop and is_green and cfg["MIN_EMA_DIST"] < ema_dist < cfg["MAX_EMA_DIST"] and 28 < r["rsi"] < 42:
                sig.iloc[i] = 1

        elif vol_spike and btc_status == "down":
            if euphoria_pop and is_red and -cfg["MAX_EMA_DIST"] < ema_dist < -cfg["MIN_EMA_DIST"] and 58 < r[
                "rsi"] < 72:
                sig.iloc[i] = -1
    return sig


# ==================== СИМУЛЯЦИЯ ====================
def simulate_trade(df, idx, side, capital, cfg):
    entry_price = df.iloc[idx + 1]["open"]
    if entry_price <= 0: return None

    entry_row = df.iloc[idx]
    entry_rsi = entry_row["rsi"]
    entry_vol_ratio = entry_row["vol_ratio"]
    entry_ema_dist = (entry_row["close"] / entry_row["ema_200"] - 1) * 100

    if pd.isna(entry_rsi): entry_rsi = 0.0
    if pd.isna(entry_vol_ratio): entry_vol_ratio = 0.0
    if pd.isna(entry_ema_dist): entry_ema_dist = 0.0

    risk_amount = capital * cfg["RISK_PER_TRADE_PCT"]
    initial_notional = risk_amount / cfg["SL_PCT"]
    initial_qty = initial_notional / entry_price

    entries = [{"price": entry_price, "qty": initial_qty}]
    total_qty = initial_qty

    if side == "long":
        trail_stop = entry_price * (1 - cfg["SL_PCT"])
        initial_stop = trail_stop
        highest = entry_price
    else:
        trail_stop = entry_price * (1 + cfg["SL_PCT"])
        initial_stop = trail_stop
        lowest = entry_price

    pyramid_hits = 0
    exit_price, exit_reason, exit_idx = None, None, None
    end_j = min(idx + 1 + cfg["MAX_HOLD_CANDLES"], len(df))

    for j in range(idx + 1, end_j):
        row = df.iloc[j]
        high, low = row["high"], row["low"]
        candles_held = j - idx

        if side == "long" and low <= trail_stop:
            exit_price, exit_reason, exit_idx = trail_stop, ("TRAIL" if trail_stop > initial_stop else "SL"), j
            break
        if side == "short" and high >= trail_stop:
            exit_price, exit_reason, exit_idx = trail_stop, ("TRAIL" if trail_stop < initial_stop else "SL"), j
            break

        if cfg["PYRAMID_ENABLED"] and pyramid_hits < cfg["PYRAMID_LEVELS"]:
            if side == "long":
                p_price = entry_price * (1 + cfg["PYRAMID_STEP_PCT"] * (pyramid_hits + 1))
                if high >= p_price:
                    add_qty = initial_qty * cfg["PYRAMID_SIZE_FRACTION"]
                    entries.append({"price": p_price, "qty": add_qty})
                    total_qty += add_qty
                    pyramid_hits += 1
            else:
                p_price = entry_price * (1 - cfg["PYRAMID_STEP_PCT"] * (pyramid_hits + 1))
                if low <= p_price:
                    add_qty = initial_qty * cfg["PYRAMID_SIZE_FRACTION"]
                    entries.append({"price": p_price, "qty": add_qty})
                    total_qty += add_qty
                    pyramid_hits += 1

        if side == "long":
            highest = max(highest, high)
        else:
            lowest = min(lowest, low)

        if cfg["TRAILING_ENABLED"]:
            if side == "long" and highest >= entry_price * (1 + cfg["TRAIL_ACTIVATE_PCT"]):
                dist = cfg["TRAIL_TIGHTEN_PCT"] if pyramid_hits >= 2 else cfg["TRAIL_DISTANCE_PCT"]
                new_stop = highest * (1 - dist)
                if new_stop > trail_stop: trail_stop = new_stop
            elif side == "short" and lowest <= entry_price * (1 - cfg["TRAIL_ACTIVATE_PCT"]):
                dist = cfg["TRAIL_TIGHTEN_PCT"] if pyramid_hits >= 2 else cfg["TRAIL_DISTANCE_PCT"]
                new_stop = lowest * (1 + dist)
                if new_stop < trail_stop: trail_stop = new_stop

        if pyramid_hits >= 1:
            avg_entry = sum(e["price"] * e["qty"] for e in entries) / total_qty
            if side == "long":
                protect = avg_entry * 1.001
                if protect > trail_stop: trail_stop = protect
            else:
                protect = avg_entry * 0.999
                if protect < trail_stop: trail_stop = protect

        if candles_held >= cfg["EARLY_EXIT_CANDLES"] and pyramid_hits == 0:
            exit_price, exit_reason, exit_idx = row["close"], "EARLY_EXIT", j
            break

    if exit_price is None:
        exit_idx = end_j - 1
        exit_price = df.iloc[exit_idx]["close"]
        exit_reason = "TIME"

    gross, entry_notional = 0.0, 0.0
    for e in entries:
        gross += ((exit_price - e["price"]) if side == "long" else (e["price"] - exit_price)) * e["qty"]
        entry_notional += e["price"] * e["qty"]
    commission = (entry_notional + exit_price * total_qty) * cfg["COMMISSION"]
    pnl = gross - commission

    return {
        "side": side, "entry_time": df.iloc[idx + 1]["timestamp"], "exit_time": df.iloc[exit_idx]["timestamp"],
        "entry_price": round(entry_price, 4), "exit_price": round(exit_price, 4),
        "exit_reason": exit_reason, "pyramid_hits": pyramid_hits, "pnl": round(pnl, 2),
        "entry_rsi": round(entry_rsi, 1), "entry_vol_ratio": round(entry_vol_ratio, 1),
        "entry_ema_dist": round(entry_ema_dist, 2),
    }


# ==================== БЭКТЕСТ ====================
def backtest(data, cfg):
    capital = cfg["INITIAL_CAPITAL"]
    equity = [capital]
    trades = []
    all_sig = []

    if "BTCUSDT" not in data:
        print("❌ Нет данных по BTCUSDT для хеджирования. Прерываем.")
        return [], []

    print("Анализ тренда BTC для хеджирования...", flush=True)
    btc_trend_map = get_btc_trend(data["BTCUSDT"])

    print("Генерация сигналов...", flush=True)
    for sym, df in data.items():
        df = add_indicators(df)
        df["signal"] = generate_signals(df, btc_trend_map, cfg)
        data[sym] = df
        for i, r in df.iterrows():
            if r["signal"] != 0:
                all_sig.append({"time": r["timestamp"], "symbol": sym, "signal": r["signal"], "index": i})

    all_sig.sort(key=lambda x: x["time"])
    print(f"Найдено сигналов за 2 года: {len(all_sig)}", flush=True)

    active_trades = []

    # ГЛАВНОЕ ИСПРАВЛЕНИЕ: Капитал обновляется только по факту закрытия
    for sig in all_sig:
        t = sig["time"]

        # 1. "Сеттлим" (закрываем) все сделки, время выхода которых наступило ДО текущего сигнала
        newly_closed = [a for a in active_trades if a["exit_time"] <= t]
        for nt in newly_closed:
            capital += nt["pnl"]
            equity.append(capital)
            trades.append(nt)
            active_trades.remove(nt)

        sym = sig["symbol"]
        df = data[sym]
        idx = sig["index"]

        if idx + 1 >= len(df): continue
        # Проверяем, нет ли уже открытой сделки по этому символу
        if any(a["symbol"] == sym for a in active_trades): continue
        # Проверяем лимит одновременных позиций
        if len(active_trades) >= cfg["MAX_CONCURRENT_POSITIONS"]: continue

        # Оценка маржи (строго на основе УЖЕ ЗАКРЫТОГО капитала)
        est_notional = capital * cfg["RISK_PER_TRADE_PCT"] / cfg["SL_PCT"]
        est_margin = (est_notional * (1 + cfg["PYRAMID_LEVELS"] * cfg["PYRAMID_SIZE_FRACTION"])) / cfg["LEVERAGE"]

        current_used_margin = len(active_trades) * est_margin
        if current_used_margin + est_margin > capital * cfg["MAX_MARGIN_USAGE"]:
            continue

        side = "long" if sig["signal"] == 1 else "short"

        # Симулируем сделку (размер позиции считается от текущего capital)
        result = simulate_trade(df, idx, side, capital, cfg)
        if result is None: continue

        result["symbol"] = sym
        # Мы НЕ добавляем PnL сразу! Мы кладем сделку в активные.
        active_trades.append(result)

    # В конце добавляем оставшиеся сделки, которые не успели закрыться
    for nt in active_trades:
        capital += nt["pnl"]
        equity.append(capital)
        trades.append(nt)

    # Сортируем сделки по времени закрытия для красивого вывода
    trades.sort(key=lambda x: x["exit_time"])

    return trades, equity

def print_stats(trades, equity, cfg):
    df = pd.DataFrame(trades)
    if df.empty:
        print("\n❌ Сделок не было.")
        return

    df.to_csv("detailed_trades_2years.csv", index=False)

    wins = df[df["pnl"] > 0]
    losses = df[df["pnl"] <= 0]

    print("\n" + "=" * 68)
    print("📊 ИТОГОВАЯ СТАТИСТИКА ЗА 2 ГОДА (Снайпер v7.0 - Танк)")
    print("=" * 68)
    print(f"Всего сделок:         {len(df)}")
    print(f"Прибыльных:           {len(wins)} ({len(wins) / len(df) * 100:.1f}%)")
    print(f"Убыточных:            {len(losses)} ({len(losses) / len(df) * 100:.1f}%)")
    if len(wins): print(f"Средняя прибыль:      ${wins['pnl'].mean():.2f}")
    if len(losses): print(f"Средний убыток:       ${losses['pnl'].mean():.2f}")
    if len(losses) and losses["pnl"].sum() != 0:
        print(f"Profit factor:        {wins['pnl'].sum() / abs(losses['pnl'].sum()):.2f}")
    print(f"Итоговый капитал:     ${equity[-1]:,.2f}")
    print(f"Доходность за 2 года: {(equity[-1] / cfg['INITIAL_CAPITAL'] - 1) * 100:+.2f}%")

    eq_s = pd.Series(equity)
    max_dd = (eq_s.cummax() - eq_s).max()
    max_dd_pct = max_dd / eq_s.cummax().max() * 100 if eq_s.cummax().max() > 0 else 0
    print(f"Макс. просадка:       ${max_dd:,.2f} ({max_dd_pct:.2f}%)")

    print("\n--- Распределение пирамидинга ---")
    for n in range(cfg["PYRAMID_LEVELS"] + 1):
        sub = df[df["pyramid_hits"] == n]
        if len(sub):
            print(f"  {n} добавок: {len(sub):3d} сделок, "
                  f"средний PnL ${sub['pnl'].mean():+,.2f}, "
                  f"winrate {(sub['pnl'] > 0).mean() * 100:.1f}%")

    plt.figure(figsize=(14, 7))
    plt.plot(equity, marker="o", markersize=3, color='darkgreen', linewidth=2, markeredgecolor='black')
    plt.axhline(cfg["INITIAL_CAPITAL"], color="red", ls="--", label="Старт $10k")
    plt.title("Кривая капитала — Снайпер v7.0 (2 года)")
    plt.xlabel("Сделка")
    plt.ylabel("Капитал, $")
    plt.grid(alpha=0.3);
    plt.legend();
    plt.tight_layout()
    plt.savefig("equity_2years.png", dpi=120);
    plt.show()


# ==================== ЗАПУСК ====================
if __name__ == "__main__":
    # 1. Фильтруем монеты (по launchTime)
    valid_symbols = get_valid_symbols()
    if not valid_symbols:
        print("❌ Не найдено монет с историей 2+ года.")
        exit()

    # 2. Скачиваем 1H свечи за 2 года
    end = datetime.now(timezone.utc)
    start = end - timedelta(days=CONFIG["DAYS_BACK"])
    s_ms, e_ms = int(start.timestamp() * 1000), int(end.timestamp() * 1000)

    data = {}
    print(f"\nЗагрузка 1H данных за 2 года для {len(valid_symbols)} монет...", flush=True)
    for idx, s in enumerate(valid_symbols):
        print(f"Загрузка {s} ({idx + 1}/{len(valid_symbols)})...", end="\r", flush=True)
        df = fetch_klines(s, CONFIG["INTERVAL"], s_ms, e_ms, force_reload=CONFIG["FORCE_RELOAD"])
        if len(df) > 100:
            data[s] = df
    print(f"\n✅ Загружено монет: {len(data)}", flush=True)

    if not data:
        print("Нет данных.")
        exit()

    # 3. Запускаем бэктест
    print("\nЗапуск 2-летнего бэктеста (Снайпер v7.0)...", flush=True)
    trades, equity = backtest(data, CONFIG)
    print_stats(trades, equity, CONFIG)